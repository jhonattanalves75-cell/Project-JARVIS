package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var speech: TextToSpeech
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private val cyan = Color.rgb(66, 217, 255)
    private val dark = Color.rgb(5, 10, 18)
    private val requestVoice = 101
    private val requestPermission = 102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = dark
        window.navigationBarColor = dark
        speech = TextToSpeech(this, this)
        buildUi()
        addMessage("JARVIS", "Olá. Sou o JARVIS. Posso falar contigo e pesquisar na Internet. A conversa inteligente por IA ainda não está ligada.")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 18)
            setBackgroundColor(dark)
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S"
            textSize = 27f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(cyan)
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 58))

        val subtitle = TextView(this).apply {
            text = "ASSISTENTE PESSOAL • ONLINE"
            textSize = 11f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, 28))

        val orb = TextView(this).apply {
            text = "◉"
            textSize = 64f
            setTextColor(cyan)
            gravity = Gravity.CENTER
            contentDescription = "Ativar reconhecimento de voz"
            setOnClickListener { startVoiceInput() }
        }
        root.addView(orb, LinearLayout.LayoutParams(-1, 105))

        val scroll = ScrollView(this)
        chat = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(2, 8, 2, 8)
        }
        scroll.addView(chat)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        input = EditText(this).apply {
            hint = "Escreve uma mensagem..."
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 16f
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_SEND
            background = rounded(Color.rgb(17, 28, 42), 18)
            setPadding(16, 12, 16, 12)
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) { sendText(); true } else false
            }
        }
        root.addView(input, LinearLayout.LayoutParams(-1, 54))

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val voiceButton = makeButton("🎙 Falar") { startVoiceInput() }
        val sendButton = makeButton("Enviar") { sendText() }
        val searchButton = makeButton("Pesquisar") { searchWeb() }
        buttons.addView(voiceButton, LinearLayout.LayoutParams(0, 52, 1f))
        buttons.addView(sendButton, LinearLayout.LayoutParams(0, 52, 1f))
        buttons.addView(searchButton, LinearLayout.LayoutParams(0, 52, 1f))
        root.addView(buttons)
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 12f
            setTextColor(cyan)
            background = rounded(Color.rgb(17, 28, 42), 14)
            setOnClickListener { action() }
        }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
        setStroke(1, Color.rgb(34, 93, 120))
    }

    private fun addMessage(sender: String, message: String) {
        val view = TextView(this).apply {
            text = "$sender\n$message"
            textSize = 15f
            setTextColor(if (sender == "JARVIS") cyan else Color.WHITE)
            setPadding(14, 12, 14, 12)
            background = rounded(Color.rgb(12, 22, 34), 14)
        }
        val params = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
        params.setMargins(0, 7, 0, 7)
        chat.addView(view, params)
    }

    private fun sendText() {
        val message = input.text.toString().trim()
        if (message.isEmpty()) return
        addMessage("TU", message)
        input.setText("")
        val lower = message.lowercase(Locale.ROOT)
        val reply = when {
            lower.contains("olá") || lower.contains("ola") || lower.contains("bom dia") ->
                "Olá. Como posso ajudar?"
            lower.contains("hora") ->
                "Podes consultar a hora apresentada no teu telemóvel."
            lower.contains("pesquisa") || lower.startsWith("pesquisar ") ->
                "Vou abrir uma pesquisa na Internet."
            else ->
                "Ainda não estou ligado a uma IA, por isso não consigo responder de forma inteligente a tudo. Usa Pesquisar para procurar essa informação na Internet."
        }
        addMessage("JARVIS", reply)
        speak(reply)
        if (lower.startsWith("pesquisar ")) {
            openSearch(message.removePrefix("pesquisar ").trim())
        }
    }

    private fun startVoiceInput() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), requestPermission)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-PT")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Fala com o JARVIS")
        }
        try {
            startActivityForResult(intent, requestVoice)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "O reconhecimento de voz não está disponível neste dispositivo.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Android activity result API compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestVoice && resultCode == RESULT_OK) {
            val result = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!result.isNullOrBlank()) {
                input.setText(result)
                sendText()
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestPermission && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            startVoiceInput()
        } else if (requestCode == requestPermission) {
            Toast.makeText(this, "É necessária autorização do microfone para falar com o JARVIS.", Toast.LENGTH_LONG).show()
        }
    }

    private fun searchWeb() {
        val query = input.text.toString().trim()
        if (query.isEmpty()) {
            input.hint = "Escreve o que queres pesquisar..."
            input.requestFocus()
        } else {
            addMessage("JARVIS", "A abrir a pesquisa na Internet por: $query")
            openSearch(query)
        }
    }

    private fun openSearch(query: String) {
        val url = "https://www.google.com/search?q=" + android.net.Uri.encode(query)
        startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)))
    }

    private fun speak(message: String) {
        if (::speech.isInitialized) speech.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) speech.language = Locale("pt", "PT")
    }

    override fun onDestroy() {
        if (::speech.isInitialized) speech.shutdown()
        super.onDestroy()
    }
}
