# JARVIS Assistant — projeto Android inicial

Este é um protótipo Android nativo em Kotlin. Inclui:
- Interface escura com detalhes azuis
- Reconhecimento de voz através dos serviços de voz do Android
- Respostas faladas através de TextToSpeech
- Conversa de demonstração (não é IA real)
- Pesquisa na Internet através do navegador

## Importante
Este projeto é o código-fonte, não um APK já compilado. Para gerar um APK é necessário compilar o projeto com Android SDK/Gradle, normalmente usando Android Studio num computador ou um serviço de compilação Android de confiança.

A conversa não está ligada a um modelo de IA. Não introduzas chaves secretas numa aplicação pública. Para adicionar IA com segurança, utiliza um backend próprio ou um serviço com configuração segura.

## Como compilar
1. Abre o projeto no Android Studio.
2. Aguarda a sincronização do Gradle.
3. Compila/Executa no dispositivo Android ou usa Build > Build APK(s).
4. Testa as permissões de microfone e a pesquisa.

Versão inicial de demonstração. O nome JARVIS é usado como nome de projeto inspirado num assistente fictício.
